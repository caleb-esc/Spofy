```markdown
# Mini Spotify-like App (Expo + React Native)

What this is
- A small mobile app demo that resembles a simple Spotify client.
- Homescreen with suggested tracks and a "Because you played..." personalization row.
- Search tab for tracks/artists/albums (using iTunes Search API).
- Persistent bottom player that plays 30s preview tracks (expo-av).
- Queue support (add tracks; skip next/prev).

Requirements
- Node.js (16+)
- Expo CLI (npm i -g expo-cli) — or use npx expo
- Recommended: run on a device or simulator

Install & run
1. Install dependencies:
   npm install

2. Start Expo:
   npm start

3. Open the project on your device or simulator.

Notes
- The app uses the iTunes Search API (no auth) for preview audio URLs.
- Previews are typically ~30s. If previewUrl is absent, play will be disabled.
- This demo focuses on UI and core playback/queue logic; replace iTunes API with Spotify API if you want a production-grade integration (requires OAuth).
```